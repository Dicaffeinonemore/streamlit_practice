﻿"""Verify the explicit named-source atlas against original RGBA pixels."""
from pathlib import Path
from PIL import Image
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
m=json.loads((ROOT/'data/named-sprites.json').read_text(encoding='utf8'))
a=Image.open(ROOT/'assets/named/combat.png').convert('RGBA');src={}
for key,r in m['sources'].items():
 p=ROOT/r['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256'];src[key]=Image.open(p).convert('RGBA')
for f in m['frames']:
 x,y,w,h=f['atlas'];original=src[f['source']].crop(f['rect']);cut=a.crop((x,y,x+w,y+h))
 assert cut.size==original.size and cut.tobytes()==original.tobytes(),f['id']
 assert f['scale']>0 and all(isinstance(n,(int,float)) for n in f['anchor'])
for actor,clips in m['clips'].items():
 for clip,ids in clips.items():
  assert ids and all(0<=i<len(m['frames']) for i in ids)
  expected={'boss1':{'gorath_motion','gorath_moves'},'boss2p2':{'witch2'},'boss3':{'gold'},'boss4':{'ice'},'player':{'player'}}.get(actor,{'soldiers1'})
  assert all(m['frames'][i]['source'] in expected for i in ids),(actor,clip)
print('PASS named source hashes,',len(m['frames']),'lossless RGBA crops, anchors and eight exclusive role mappings')

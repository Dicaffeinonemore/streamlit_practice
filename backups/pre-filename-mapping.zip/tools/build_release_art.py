﻿from pathlib import Path
from PIL import Image
import json,base64,io
rows=json.loads(Path('data/latest-assets.json').read_text(encoding='utf8')); imgs=[r for r in rows if 'size'in r]; out=Path('assets/release');out.mkdir(exist_ok=True)
choices={'field1':(4,None),'boss1':(3,None),'field2':(17,None),'boss2':(15,None),'phase2':(164,(0,205,1672,660)),'field3':(19,None),'boss3':(18,None),'approach3':(20,None),'field4':(12,None),'boss4':(12,None),'phase4':(13,None),'field5':(161,(0,0,1983,390)),'boss5':(161,(0,402,1983,793)),'phase5':(162,(0,0,2068,700)),'continue':(9,None),'newgame':(10,None),'settings':(11,None)}
payload={}
def save(key,im):
 im.thumbnail((960,540),Image.Resampling.NEAREST);b=io.BytesIO();im.save(b,format='PNG',optimize=True);(out/(key+'.png')).write_bytes(b.getvalue());payload[key]='data:image/png;base64,'+base64.b64encode(b.getvalue()).decode()
for key,(n,box) in choices.items():
 r=imgs[n];im=Image.open(Path('assets/incoming')/r['source']);im=im.crop(box) if box else im.copy();save(key,im);r['status']='applied';r.setdefault('outputs',[]).append('assets/release/'+key+'.png');r['treatment']='Preserved source; explicit panel crop where necessary, nearest-neighbor reduction. Background only, no collision.'
gif=Image.open(Path('assets/incoming')/imgs[14]['source'])
for i in range(6):
 gif.seek(min(gif.n_frames-1,round(i*(gif.n_frames-1)/5)));save('opening'+str(i),gif.convert('RGB'))
imgs[14]['status']='applied as six scene stills, not complete character animation'
for r in rows:
 if r['status']=='pending review':r['status']='held';r['reason']='Unverified frame bounds / overlapping effects or reference artwork; keep existing runtime sprites. No Aseprite file supplied.'
Path('data/latest-assets.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf8')
Path('release-art.js').write_text("'use strict';\nconst RELEASE_ART = "+json.dumps(payload)+";\nconst RELEASE_IMAGES = {};\nfor (const [key, src] of Object.entries(RELEASE_ART)) { const im = new Image(); im.src = src; RELEASE_IMAGES[key] = im; }\n",encoding='utf8')

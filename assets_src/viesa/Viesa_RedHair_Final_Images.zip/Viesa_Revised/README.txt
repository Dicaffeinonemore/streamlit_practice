Viesa - Revised Sprite Collection (v2)

11 original PNG files. No recompression, resizing, background removal or recoloring.

00_Master            : Viesa design master reference (bow WITHOUT blades - in-game bow has blade tips)
01_Character_Motions : 8 sprite sheets, green background (#00FF00), facing right
02_Basic_Effects     : 1 sheet, black background - normal arrow / fade / sniper arrow / charge glow / hit spark / dash streak + landing dust
03_Ultimate_Effects  : 1 sheet, black background - phantom arrows / volley / moon sigil / impact / giant arrow / explosion

Actual frame counts (checked by eye, use these, not the file names):
01 Sniper            : draw 6 / release 6
02 Rapid fire        : start 4 / loop 6 / end 4
03 Dash + backflip   : dash 7 / backflip 8
04 Ultimate          : leap 6 / summon 4 / barrage loop 7 / final+landing 6   (file name says 6_5_6_7)
05 Movement          : idle 8 / walk 8 / run 8
06 Melee             : slash1 5 / slash2 5 / kick 6   (sheet has black cell border lines - remove)
07 Shot / jump       : quick shot 6 / jump 6 / jump shot 5
08 Damage            : hurt 4 / knockdown 6 / get up 6 / death 5   (file name says 4_7_6_6)
02 Basic effects     : arrow 1 + trail 3 / fade 5 / sniper arrow 4 / charge glow 6 / hit spark 6 / dash streak 5 + landing dust 5
03 Ultimate effects  : phantom arrows 4 variants / volley 4 / sigil 6 / impact 6 / giant arrow 4 / explosion 7
